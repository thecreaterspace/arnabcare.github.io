#include "include/screen.h"
kmain()
{       
        clearScreen();
        print(“Welcome to Grape OS“);
}
